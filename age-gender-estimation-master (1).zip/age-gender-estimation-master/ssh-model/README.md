Put pretrained ESSH model here
